# ClassGraph Issue
Changing class graph version in pom.xml from 4.8.59 to 4.8.175 causes the issue.