package com.example;

public class YourClass {

  void sayHello() {
    System.out.println("Hello from YourClass!");
  }

}
