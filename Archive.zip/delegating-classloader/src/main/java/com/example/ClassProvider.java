package com.example;

import java.net.URL;
import java.net.URLClassLoader;

public class ClassProvider {
  private final URLClassLoader classLoader;

  public ClassProvider(URL[] urls, ClassLoader parent) {
    this.classLoader = new DelegatingClassLoader(urls, parent);
  }

  public URLClassLoader getClassLoader() {
    // Thread.currentThread().setContextClassLoader(classLoader);
    return classLoader;
  }
}
