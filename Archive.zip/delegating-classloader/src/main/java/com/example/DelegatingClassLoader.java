package com.example;

import java.net.URL;
import java.net.URLClassLoader;

public class DelegatingClassLoader extends URLClassLoader {
  public DelegatingClassLoader(URL[] urls, ClassLoader parent) {
    super(urls, parent);
  }

  @Override
  public Class<?> loadClass(String name) throws ClassNotFoundException {
    // Optionally modify class loading behavior
    return super.loadClass(name);
  }
}
