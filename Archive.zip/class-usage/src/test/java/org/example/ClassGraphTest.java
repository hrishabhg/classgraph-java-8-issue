package org.example;

import com.example.ClassProvider;
import io.github.classgraph.ClassGraph;
import io.github.classgraph.ScanResult;
import org.junit.Test;

import java.net.URL;
import java.util.List;

import static org.junit.Assert.assertTrue;

public class ClassGraphTest {

  @Test
  public void testClassGraphWithDelegatingClassLoader() throws Exception {
    // get Java runtime version
    System.out.println("Java Runtime Version: " + System.getProperty("java.runtime.version"));

    // Path to the directory where compiled classes are located
    URL[] urls = new URL[]{new URL(
        "file://" + System.getProperty("user.dir") + "/delegating-classloader/target/classes/")};
    ClassProvider classProvider = new ClassProvider(urls, ClassLoader.getSystemClassLoader());

    Thread.currentThread().setContextClassLoader(ClassGraphTest.class.getClassLoader());
    // Scan with ClassGraph using the custom class loader
    try (ScanResult scanResult = new ClassGraph()
        .enableAnnotationInfo()
        .ignoreParentClassLoaders() // Use custom class loader
        .scan()) {

      // Print all class names found for debugging
      List<String> classNames = scanResult.getAllClasses().getNames();
      System.out.println("Classes found: (ignoredParentClassLoader)" + classNames.size());
//      for (String className : classNames) {
//        System.out.println(className);
//      }

//      String[] testClasses = new String[]{
//          "org.example.MyClass",
//          "com.example.YourClass",
//      };
//
//      for (String testClass : testClasses) {
//        // assertTrue("Expected class not found: " + testClass, classNames.contains(testClass));
//      }
    }

    // load classes without ignoring parent class loaders to see if the count is same or different
    try (ScanResult scanResult = new ClassGraph()
        .enableAnnotationInfo()
        .scan()) {

      // Print all class names found for debugging
      List<String> classNames = scanResult.getAllClasses().getNames();
      System.out.println("Classes found:" + classNames.size());
//      for (String className : classNames) {
//        System.out.println(className);
//      }

//      String[] testClasses = new String[]{
//          "org.example.MyClass",
//          "com.example.YourClass",
//
//      };
//
//      for (String testClass : testClasses) {
//        assertTrue("Expected class not found: " + testClass, classNames
//            .contains(testClass));
//      }

    }
  }
}
